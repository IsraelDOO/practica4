package Modelo;

public class Persona {
    private String nombre;
    private String correo;
    private String contra;
    private String fecha;
    
    public Persona(String nombre, String correo, String contra, String fecha){
        this.nombre = nombre;
        this.correo = correo;
        this.contra = contra;
        this.fecha = fecha;
    }

    public String getNombre(){
        return nombre;
    }
    
    public String getCorreo() {
        return correo;
    }

    public String getContra() {
        return contra;
    }
        
    public String getFecha() {
        return fecha;
    }
}

